import os
from openai import AsyncOpenAI
from typing import AsyncGenerator, Union, List, Dict, Any
import config

class LLMService:
    def __init__(self):
        # Инициализируем только клиент Groq
        self.groq_client = AsyncOpenAI(
            api_key=config.GROQ_API_KEY, 
            base_url="https://api.groq.com/openai/v1"
        )

    async def generate(
        self,
        messages: List[Dict[str, str]],
        model: str = "llama3-70b-8192", # Модель Groq по умолчанию
        temperature: float = 0.7,
        stream: bool = False,
    ) -> Union[str, AsyncGenerator[str, None]]:
        """
        Генерирует ответ через API Groq. 
        Возвращает готовую строку (если stream=False) или асинхронный генератор текстовых фрагментов (если stream=True).
        """
        try:
            client = self.groq_client

            if stream:
                response = await client.chat.completions.create(
                    model=model, 
                    messages=messages, 
                    temperature=temperature, 
                    stream=True
                )
                
                # Оборачиваем поток для выдачи чистых строк
                async def stream_generator() -> AsyncGenerator[str, None]:
                    async for chunk in response:
                        if chunk.choices and chunk.choices[0].delta.content:
                            yield chunk.choices[0].delta.content
                            
                return stream_generator()
                
            else:
                response = await client.chat.completions.create(
                    model=model,
                    messages=messages,
                    temperature=temperature,
                    stream=False,
                )
                return response.choices[0].message.content
                
        except Exception as e:
            error_msg = f"Ошибка генерации ответа: {str(e)}"
            if stream:
                async def error_gen() -> AsyncGenerator[str, None]:
                    yield error_msg
                return error_gen()
            return error_msg
