import json
import re
import traceback
import asyncio
import os
from core.llm import LLMService

class Agent:
    def __init__(self, tools_registry, system_prompt=None):
        self.llm = LLMService()
        self.tools = tools_registry
        
        # Load system prompt from file if not provided
        if not system_prompt:
            try:
                # Look in root directory now
                with open("system_prompt.txt", "r", encoding="utf-8") as f:
                    self.system_prompt = f.read()
            except Exception as e:
                print(f"Error loading system prompt: {e}")
                self.system_prompt = "You are a helpful AI agent."
        else:
            self.system_prompt = system_prompt

    def _build_prompt(self, history):
        tool_desc = self.tools.get_descriptions()
        try:
            system_msg = self.system_prompt.format(tool_descriptions=tool_desc)
        except Exception as e:
            # Fallback if formatting fails (e.g. braces issues)
            system_msg = self.system_prompt.replace("{tool_descriptions}", tool_desc)
            
        messages = [{"role": "system", "content": system_msg}]
        messages.extend(history)
        return messages

    def _extract_json(self, text):
        """Extracts JSON block from text."""
        try:
            # 1. Try finding Markdown code blocks with 'json' language specifier
            match = re.search(r"```json\s*(\{.*?\})\s*```", text, re.DOTALL)
            if match:
                return json.loads(match.group(1))
        except:
            pass

        try:
            # 2. Try finding generic code blocks
            match = re.search(r"```\s*(\{.*?\})\s*```", text, re.DOTALL)
            if match:
                return json.loads(match.group(1))
        except:
            pass

        try:
            # 3. Try finding just the first valid JSON object in the text
            match = re.search(r"(\{.*\})", text, re.DOTALL)
            if match:
                return json.loads(match.group(1))
        except:
            pass
            
        # 4. Fallback: Repair malformed JSON (common LLM error: missing closing braces)
        try:
            start_idx = text.find('{')
            if start_idx != -1:
                potential_json = text[start_idx:].strip()
                # Remove trailing backticks if they exist
                if potential_json.endswith("```"):
                    potential_json = potential_json[:-3].strip()
                
                # Try appending up to 5 closing braces
                for i in range(1, 6):
                    try:
                        return json.loads(potential_json + ('}' * i))
                    except:
                        continue
        except:
            pass
            
        return None

    async def run(self, user_input, history=None, tool_context=None):
        """
        Main ReAct loop. Yields status updates asynchronously.
        Returns final response text.
        """
        if history is None:
            history = []
        
        # Add user input to history if it's new
        if not history or history[-1]["role"] != "user":
            history.append({"role": "user", "content": user_input})

        max_turns = 100 # Increased limit
        turn = 0
        
        # Loop detection history
        tool_history = [] 

        while turn < max_turns:
            turn += 1
            yield {"status": "thinking", "message": "Analysing request..."}

            # 1. Call LLM with streaming
            messages = self._build_prompt(history)
            
            # Use DeepSeek for complex reasoning
            stream_gen = await self.llm.generate(messages, provider="deepseek", model="default", stream=True)
            
            response_buffer = ""
            is_tool_call = None
            
            try:
                async for chunk in stream_gen:
                    if isinstance(chunk, str): 
                         delta = chunk
                    else:
                        try:
                            delta = chunk.choices[0].delta.content or ""
                        except:
                            delta = ""
                    
                    previous_is_tool_call = is_tool_call
                    response_buffer += delta
                    
                    # Heuristic to detect if it's a tool call (JSON) or text
                    if is_tool_call is None:
                        stripped = response_buffer.lstrip()
                        if len(stripped) > 0:
                            if stripped.startswith("```json") or (len(stripped) > 5 and stripped.startswith("{")):
                                is_tool_call = True
                                yield {"status": "thinking", "message": "Planning tool use..."}
                            elif len(stripped) > 20 and not (stripped.startswith("`") or stripped.startswith("{")):
                                # Assume text if not started JSON after 20 chars
                                is_tool_call = False
                    
                    # If definitely text, yield stream
                    if is_tool_call is False:
                        if previous_is_tool_call is None:
                            # Just decided it's text. Yield everything so far.
                            yield {"status": "final_stream", "content": response_buffer}
                        else:
                            # Already decided. Yield just delta.
                            yield {"status": "final_stream", "content": delta}
                            
                    # If tool call detected and closed, stop stream immediately!
                    if is_tool_call is True:
                        if response_buffer.strip().endswith("```") and "```json" in response_buffer:
                             break 
                        if response_buffer.count('{') > 0 and response_buffer.count('{') == response_buffer.count('}'):
                             if self._extract_json(response_buffer):
                                 break 

            except asyncio.CancelledError:
                raise  # Propagate cancellation immediately
            except Exception as e:
                pass

            response_text = response_buffer
            
            # Add LLM response to history
            history.append({"role": "assistant", "content": response_text})

            # 2. Check for Tool Call
            tool_call = self._extract_json(response_text)
            
            if tool_call:
                tool_name = tool_call.get("tool")
                tool_args = tool_call.get("args", {})
                
                # Loop Detection Logic
                current_call = (tool_name, json.dumps(tool_args, sort_keys=True))
                tool_history.append(current_call)
                
                # Check last 3 calls
                if len(tool_history) >= 3:
                    last_3 = tool_history[-3:]
                    if all(c == current_call for c in last_3):
                        # Repeated 3 times
                        if len(tool_history) >= 4 and tool_history[-4] == current_call:
                             # Repeated 4 times - STOP
                             yield {"status": "final", "content": "Error: Agent is stuck in a loop repeating the same action. Stopping."}
                             return
                        else:
                             # Repeated 3 times - Warn
                             history.append({"role": "system", "content": "WARNING: You are repeating the same tool call. Please change your strategy or stop."})
                
                yield {"status": "tool_use", "tool": tool_name, "args": tool_args}
                
                # 3. Execute Tool
                try:
                    if self.tools.is_async(tool_name):
                        coro = self.tools.execute(tool_name, tool_context=tool_context, **tool_args)
                        if asyncio.iscoroutine(coro):
                            result = await coro
                        else:
                            result = coro
                    else:
                        result = await asyncio.to_thread(self.tools.execute, tool_name, tool_context=tool_context, **tool_args)
                        
                    result_msg = f"Tool '{tool_name}' output:\n{result}"
                except Exception as e:
                    result_msg = f"Tool '{tool_name}' error:\n{traceback.format_exc()}"
                
                # Add observation to history
                history.append({"role": "user", "content": f"Observation: {result_msg}"})
                yield {"status": "observation", "result": result_msg}
                
            else:
                # No tool call = Final Answer
                # Yield final status even if text was streamed, to trigger final save/edit in bot.py
                yield {"status": "final", "content": response_text}
                return

        yield {"status": "final", "content": "Error: Maximum turns reached."}
