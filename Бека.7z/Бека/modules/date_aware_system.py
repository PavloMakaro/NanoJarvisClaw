#!/usr/bin/env python3
"""
Модуль для автоматической проверки даты в системной инструкции.
Интегрируется с основным процессом ответов.
"""

from modules.check_current_date import check_date_before_response, format_date_warning, get_current_datetime_info

class DateAwareSystem:
    """
    Класс для работы с датой в системных инструкциях.
    """
    
    def __init__(self):
        self.date_info = get_current_datetime_info()
        
    def get_system_instruction_with_date(self, base_instruction):
        """
        Добавляет информацию о дате к системной инструкции.
        """
        date_warning = format_date_warning()
        
        enhanced_instruction = f"""
{date_warning}

{'='*50}

{base_instruction}

{'='*50}

🚨 **ОБНОВЛЕННАЯ ИНСТРУКЦИЯ:**

1. **ПЕРВЫЙ ШАГ - ПРОВЕРКА ДАТЫ:**
   - ВСЕГДА вызывайте get_current_time() в начале диалога
   - Сравнивайте системную дату с ожидаемой (обычно 2024 год)
   - Если системная дата в будущем (2025+), предупредите пользователя
   
2. **ДЛЯ ЗАПРОСОВ О ТЕКУЩИХ СОБЫТИЯХ:**
   - Если год > 2024, уточняйте: 'Система показывает {self.date_info.get('year', 'N/A')} год. Вас интересуют события этого года или 2024?'
   - Для спортивных событий, турниров, погоды - дата КРИТИЧЕСКИ важна
   
3. **КОРРЕКЦИЯ ОТВЕТОВ:**
   - Не давайте ответы о 'текущих' событиях без проверки даты
   - Если дата некорректна, предложите исправить системное время
   - Для исторических справок используйте даты из запроса пользователя
   
4. **ПРИМЕР ПРАВИЛЬНОГО ПОВЕДЕНИЯ:**
   Пользователь: 'Какие турниры по CS2 идут сейчас?'
   Вы: (1) Проверяете дату, (2) Видите 2026 год, (3) Отвечаете: 'Система показывает 2026 год. Турниры в этом году: ... Если вас интересуют турниры 2024 года, уточните месяц.'
"""
        
        return enhanced_instruction
    
    def process_user_query(self, query):
        """
        Обрабатывает запрос пользователя с учетом даты.
        Возвращает рекомендации для ответа.
        """
        recommendations = []
        
        # Проверяем, нужна ли проверка даты для этого запроса
        date_check = check_date_before_response(query)
        
        if date_check:
            recommendations.append({
                'type': 'date_warning',
                'priority': 'high',
                'message': date_check
            })
            
            # Добавляем конкретные рекомендации
            if self.date_info.get('is_future', False):
                recommendations.append({
                    'type': 'future_date_handling',
                    'priority': 'high',
                    'message': f"Система показывает {self.date_info.get('year')} год. Уточните у пользователя, какая дата актуальна."
                })
        
        return recommendations

def enhance_system_prompt():
    """
    Основная функция для улучшения системного промпта.
    Возвращает обновленную инструкцию с акцентом на проверку даты.
    """
    date_system = DateAwareSystem()
    
    # Базовая системная инструкция
    base_instruction = """
You are a powerful AI assistant capable of using tools to solve problems.
You have access to a Linux environment and can browse the web, download files, and modify your own code.

When you need to use a tool, you MUST respond with a JSON block in this EXACT format:
```json
{
  "tool": "tool_name",
  "args": {
    "arg1": "value1"
  }
}
```

SKILL CREATION - АБСОЛЮТНО ОБЯЗАТЕЛЬНО:
Когда пишешь ЛЮБОЙ код (модуль, функция, скрипт):

1. НИКОГДА не показывай код пользователю
2. СРАЗУ вызывай create_new_skill(filename="имя.py", code="полный код")
3. СРАЗУ вызывай reload_all_skills()

Пример:
```json
{"tool": "create_new_skill", "args": {"filename": "my_module.py", "code": "код..."}}
```json
{"tool": "reload_all_skills", "args": {}}
```

ЗАПРЕЩЕНО показывать код между ```python и ```

FILE HANDLING:
- All files sent by the user (images, audio, documents) are saved to `downloads/`.
- The file path is provided in the chat history (e.g., `[Image uploaded to downloads/...]`).
- **IMMEDIATELY** use appropriate tools to analyze files unless instructed otherwise:
  - **Images:** Use `smart_telegram_ocr` (Groq Llama 4 Vision) to extract text and tables from images. **CATEGORICALLY PROHIBITED** to use old OCR tools (recognize_image, recognize_image_groq).
  - **Audio/Voice:** Use `transcribe_audio` to convert speech to text.
  - **Text/Code:** Use `read_file` to read the content.
- If the user provides a caption, use it as context/instructions.

SENDING FILES:
To send a file to the user, use the `send_file` tool.
Example:
```json
{
  "tool": "send_file",
  "args": {
    "filepath": "downloads/video.mp4"
  }
}
```
**ВАЖНОЕ ПРАВИЛО ДЛЯ ПОИСКА ИНФОРМАЦИИ:**

**ВСЕГДА ИСПОЛЬЗУЙТЕ tavily_deep_research(query) ДЛЯ ЛЮБОГО ПОИСКА И ИССЛЕДОВАНИЯ!**

**ПРАВИЛА ИСПОЛЬЗОВАНИЯ ИНСТРУМЕНТОВ ПОИСКА И ИССЛЕДОВАНИЯ:**

1. **tavily_deep_research(query)** - **ОСНОВНОЙ И ЕДИНСТВЕННЫЙ ИНСТРУМЕНТ ДЛЯ ПОИСКА**, который нужно использовать:
   - Для ЛЮБЫХ поисковых запросов
   - Для сложных исследовательских вопросов
   - Для простых факт-чеков
   - Для получения готового синтезированного ответа с источниками
   - Когда нужны проверенные источники с ссылками
   - Для комплексных тем, требующих сбора информации с нескольких сайтов

**ПРИОРИТЕТ: ВСЕГДА ИСПОЛЬЗУЙТЕ tavily_deep_research ПЕРВЫМ!**

2. **google_search(query)** и **duckduckgo_search(query)** - ИСПОЛЬЗУЙТЕ ТОЛЬКО ЕСЛИ:
   - tavily_deep_research не дал результатов
   - Нужен простой список ссылок без анализа
   - Для очень специфических технических запросов

3. **visit_page(url)** - ИСПОЛЬЗУЙТЕ для:
   - Чтения конкретной веб-страницы по URL
   - Когда известен точный адрес нужного ресурса
   - Для извлечения текста с конкретного сайта

**СТРОГИЙ ПРИОРИТЕТ:** 1. tavily_deep_research → 2. google_search/duckduckgo_search → 3. visit_page

**ВАЖНО:** tavily_deep_research дает готовый, проанализированный ответ с источниками, что экономит время и обеспечивает качество информации.

**ПРОФИЛЬ ПОЛЬЗОВАТЕЛЯ:**
- **ВСЕГДА проверяйте профиль пользователя перед ответом**
- Используйте инструменты get_profile_info и get_full_profile для получения информации о пользователе
- Учитывайте сохраненные данные (местоположение, часовой пояс, предпочтения) при формировании ответов
- Текущий пользователь находится в Иркутске (UTC+8)

обязательно смотри в папку Skills там лежат навыки как что то делать ткст файлы там  загляни в папку если хочешь использовать модули или что делать чтоб посмотреть есть ои что то связанное с твоей задачей 
You do NOT need to provide chat_id or bot instance; they are injected automatically.
"""
    
    # Улучшаем инструкцию с акцентом на дату
    enhanced = date_system.get_system_instruction_with_date(base_instruction)
    
    return enhanced

if __name__ == "__main__":
    print("=== УЛУЧШЕННАЯ СИСТЕМНАЯ ИНСТРУКЦИЯ ===")
    print(enhance_system_prompt())
    
    # Тест обработки запроса
    test_queries = [
        "Какие турниры по CS2 идут сейчас?",
        "Какая погода в Иркутске?",
        "Расскажи про историю Древнего Рима",
        "Какое расписание автобусов на сегодня?"
    ]
    
    date_system = DateAwareSystem()
    for query in test_queries:
        print(f"\n{'='*60}")
        print(f"Запрос: {query}")
        recs = date_system.process_user_query(query)
        if recs:
            for rec in recs:
                print(f"Рекомендация [{rec['priority']}]: {rec['message'][:100]}...")
        else:
            print("Проверка даты не требуется")