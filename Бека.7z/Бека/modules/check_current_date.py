#!/usr/bin/env python3
"""
Модуль для проверки текущей даты и времени системы.
Добавляет автоматическую проверку перед выполнением задач.
"""

from datetime import datetime
import pytz

def get_current_datetime_info():
    """
    Получает текущую дату и время системы с поясом.
    Возвращает словарь с подробной информацией.
    """
    try:
        # Получаем текущее время
        now = datetime.now()
        
        # Определяем часовой пояс Иркутска
        irkutsk_tz = pytz.timezone('Asia/Irkutsk')
        irkutsk_time = now.astimezone(irkutsk_tz)
        
        info = {
            'system_date': now.strftime('%Y-%m-%d'),
            'system_time': now.strftime('%H:%M:%S'),
            'system_datetime': now.strftime('%Y-%m-%d %H:%M:%S'),
            'irkutsk_date': irkutsk_time.strftime('%Y-%m-%d'),
            'irkutsk_time': irkutsk_time.strftime('%H:%M:%S'),
            'irkutsk_datetime': irkutsk_time.strftime('%Y-%m-%d %H:%M:%S'),
            'year': now.year,
            'month': now.month,
            'day': now.day,
            'weekday': now.strftime('%A'),
            'is_future': now.year > 2024,  # Проверка на будущее время
            'timezone': 'Asia/Irkutsk (UTC+8)',
            'note': 'ВСЕГДА проверяйте эту дату перед ответом на вопросы о текущих событиях!'
        }
        
        return info
        
    except Exception as e:
        return {
            'error': str(e),
            'note': 'Не удалось получить информацию о дате'
        }

def format_date_warning():
    """
    Форматирует предупреждение о проверке даты для системной инструкции.
    """
    info = get_current_datetime_info()
    
    if 'error' in info:
        return "⚠️ ВНИМАНИЕ: Не удалось проверить системную дату!"
    
    warning = f"""
⚠️ **ВАЖНОЕ ПРЕДУПРЕЖДЕНИЕ О ДАТЕ:**

📅 **СИСТЕМНАЯ ДАТА:** {info['system_datetime']}
🌏 **ИРКУТСК:** {info['irkutsk_datetime']} (UTC+8)

🔍 **АНАЛИЗ:**
• Год: {info['year']}
• Месяц: {info['month']} ({info['weekday']})
• День: {info['day']}
• Это будущее время: {'ДА' if info['is_future'] else 'НЕТ'}

🚨 **ИНСТРУКЦИЯ:**
1. ВСЕГДА проверяйте текущую системную дату перед ответом
2. Если год > 2024, информация о "текущих" событиях может быть некорректной
3. Уточняйте у пользователя, какая дата актуальна
4. Для исторических событий используйте конкретные даты из запроса

{info['note']}
"""
    
    return warning

def check_date_before_response(user_query):
    """
    Автоматически проверяет дату перед ответом на запрос пользователя.
    Возвращает предупреждение если дата некорректна.
    """
    info = get_current_datetime_info()
    
    # Ключевые слова, требующие проверки даты
    date_sensitive_keywords = [
        'сегодня', 'сейчас', 'текущий', 'идет', 'live', 'турнир', 'матч',
        'погода', 'расписание', 'новости', 'события', 'актуальн',
        'вчера', 'завтра', 'неделя', 'месяц', 'год'
    ]
    
    query_lower = user_query.lower()
    needs_date_check = any(keyword in query_lower for keyword in date_sensitive_keywords)
    
    if needs_date_check and info.get('is_future', False):
        return format_date_warning() + f"\n\n📝 **ЗАПРОС ПОЛЬЗОВАТЕЛЯ:** {user_query}"
    
    return None

if __name__ == "__main__":
    # Тестирование модуля
    print("=== ТЕСТ ПРОВЕРКИ ДАТЫ ===")
    info = get_current_datetime_info()
    for key, value in info.items():
        print(f"{key}: {value}")
    print("\n" + format_date_warning())